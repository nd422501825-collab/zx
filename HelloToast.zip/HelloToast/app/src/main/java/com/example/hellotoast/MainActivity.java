package com.example.hellotoast;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private int mCount = 0;
    private TextView mShowCount;
    private Button mButtonZero;
    private Button mButtonCount;
    private Button mButtonToast;

    private static final String STATE_COUNT = "count_state";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mShowCount = findViewById(R.id.show_count);
        mButtonZero = findViewById(R.id.button_zero);
        mButtonCount = findViewById(R.id.button_count);
        mButtonToast = findViewById(R.id.button_toast);

        if (savedInstanceState != null) {
            mCount = savedInstanceState.getInt(STATE_COUNT, 0);
        }

        updateUI();
    }

    @Override
    protected void onSaveInstanceState(@androidx.annotation.NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_COUNT, mCount);
    }

    private void updateUI() {
        if (mShowCount != null) {
            mShowCount.setText(String.valueOf(mCount));
        }

        if (mButtonCount != null) {
            if (mCount % 2 != 0) {
                setButtonBackgroundColor(mButtonCount, R.color.count_button_odd);
            } else {
                setButtonBackgroundColor(mButtonCount, R.color.count_button_even);
            }
        }

        if (mButtonZero != null) {
            if (mCount == 0) {
                setButtonBackgroundColor(mButtonZero, R.color.button_zero_gray);
            } else {
                setButtonBackgroundColor(mButtonZero, R.color.button_zero_active);
            }
        }
    }

    private void setButtonBackgroundColor(Button button, int colorResId) {
        int color = ContextCompat.getColor(this, colorResId);
        button.setBackgroundColor(color);
        button.setBackgroundTintList(ColorStateList.valueOf(color));
    }

    public void showToast(View view) {
        Toast.makeText(this, R.string.toast_message, Toast.LENGTH_SHORT).show();
    }

    public void showCount(View view) {
        mCount++;
        updateUI();
    }

    public void countUp(View view) {
        showCount(view);
    }

    public void showZero(View view) {
        mCount = 0;
        updateUI();
    }

    public void zeroCount(View view) {
        showZero(view);
    }
}
